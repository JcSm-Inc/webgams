

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <?php echo Form::model($producto,['route' => ['productos.update',  $producto->id],'method'=>'PUT','enctype'=>'multipart/form-data']); ?>

    <?php echo csrf_field(); ?>
    <div class="row my-5 py-5 z-depth-1">

            <div class="row">

                <div class="col-lg-6 mb-4 mb-lg-0 d-flex align-items-center justify-content-center">
                    <div class="view overlay zoom">
                        <img id="blah" src="<?php echo e(asset($producto->FOTO)); ?>" class="img-fluid" alt="Producto">
                        <div class="mask flex-center">
                            <label class="btn btn-outline-success btn-file">
                                Cambiar imagen<input type="file" name="FOTO" id="FOTO" style="display: none;">
                            </label>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 mb-4 mb-lg-0">
                    
                    <div class="px-4">
                        <h3 class="font-weight-bold">Actualizar Producto</h3>

                            <?php if($errors->any()): ?>
                                <p>Hay errores!</p> 
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>

                                <?php echo $__env->make('productos.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            
                    </div>
                </div>
                
            </div>
    </div>
    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebarauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\webgams\resources\views/productos/edit.blade.php ENDPATH**/ ?>