

<?php $__env->startSection('contenido'); ?>
<section class="content">
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    Productos
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('productos.create')): ?>
                            <a href="<?php echo e(route('productos.create')); ?>" class="btn btn-sm btn-primary pull-right-align">
                                Crear
                            </a>
                        <?php endif; ?>
                </div>

                <div class="card-body">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="10px">
                                    Imagen
                                </th>
                                <th width="10px"> CODPROD </th>     
                                <th>NOMBRE</th>
                                <th colspan="3">&nbsp;</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <img src="<?php echo e(asset($producto->FOTO)); ?>" alt="User Avatar" class="img-size-50 mr-3 img-circle ">
                                    </td>
                                   <td><?php echo e($producto->CODPROD); ?></td> 
                                   <td><?php echo e($producto->NOMBRE); ?></td>
                                   <td width="10px">
                                       <a href="<?php echo e(route('productos.show',$producto)); ?>" class="nav-link">
                                        <i class="far fa-eye"></i>
                                        </a>
                                    </td>
                                   <td width="10px">
                                    <a href="<?php echo e(route('productos.edit',$producto)); ?>" class="nav-link">
                                        <i class="far fa-edit"></i>
                                        </a>
                                   </td>
                                   <td width="10px">
                                        <?php echo Form::open(['route' => ['productos.destroy',$producto],
                                            'method' => 'DELETE']); ?>

                                            <button class="btn btn-xs  btn-block btn-outline-danger">
                                                <i class="far fa-trash-alt"></i>
                                            </button>
                                        <?php echo Form::close(); ?>

                                   </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($productos->render()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebarauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\webgams\resources\views/productos/index.blade.php ENDPATH**/ ?>