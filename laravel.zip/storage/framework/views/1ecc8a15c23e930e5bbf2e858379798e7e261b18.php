

<?php $__env->startSection('contenido'); ?>
<section class="content">
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    Lista de Reserva de Productos
                </div>

                <div class="card-body">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="10px"> Fecha de Reservacion </th>     
                                <th>Nombre</th>
                                <th colspan="3">&nbsp;</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $entregas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrega): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                   <td><?php echo e($entrega->FECHARESERVA); ?></td> 
                                   <td><?php echo e($entrega->personal_de_planta->user->NOMBRES.' '.$entrega->personal_de_planta->user->APELLIDOS); ?></td>
                                   <td width="10px">
                                       <a href="<?php echo e(route('entregas.create',compact('entrega'))); ?>" class="nav-link">
                                        <i class="fas fa-cart-arrow-down"></i>
                                        </a>
                                    </td>
                                   <td width="10px">
                                        <?php echo Form::open(['route' => ['entregas.destroy',$entrega],
                                            'method' => 'DELETE']); ?>

                                            <button class="btn btn-xs  btn-block btn-outline-danger">
                                                <i class="far fa-trash-alt"></i>
                                            </button>
                                        <?php echo Form::close(); ?>

                                   </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($entregas->render()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebarauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\webgams\resources\views/entregaProductos/index.blade.php ENDPATH**/ ?>