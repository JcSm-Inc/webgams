<!DOCTYPE html>
<html>
<head>
    <title>Listado de Productos</title>
    <style>
        @page  { margin: 90px 50px; }
        #header { position: fixed; left: 0px; top: -90px; right: 0px; height: 90px; background-color: orange; text-align: center; }
        #footer { position: fixed; left: 0px; bottom: -90px; right: 0px; height: 90px; background-color: lightblue; text-align: right; }
        #footer .page:after { content: counter(page, arabic); }
      </style>
</head>

<body>
    <div id="header">
        <h1>Listado de Productos</h1>
    </div>
    <div id="footer">
        <p class="page">Pagina </p>
    </div>
    <main>
<table border=1 cellspacing=0 cellpadding=2 bordercolor="#666633">
    <thead>
        <tr>
            <th width="10px">
                Imagen
            </th>
            <th width="10px" scope="col"> CODPROD </th>     
            <th scope="col">NOMBRE</th>
            <th scope="col">DESCRIPCION</th>
            <th scope="col">TIPO</th>
            <th scope="col">CANTIDAD</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <img src="<?php echo e(asset($producto->FOTO)); ?>" alt="User Avatar" width="40" height="40">
                </td>
                <td><?php echo e($producto->CODPROD); ?></td> 
                <td><?php echo e($producto->NOMBRE); ?></td>
                <td><?php echo e($producto->DESCRIPCION); ?></td>
                <td><?php echo e($producto->TIPO); ?></td>
                <td><?php echo e($producto->STOCK); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
    </main>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\webgams\resources\views/productos/pdf/productos.blade.php ENDPATH**/ ?>