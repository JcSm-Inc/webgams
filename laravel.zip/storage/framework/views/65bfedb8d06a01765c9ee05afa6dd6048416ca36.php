

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <?php echo Form::open(['route' => 'actualizarstock.store','enctype'=>'multipart/form-data','novalidate']); ?>

    <?php echo csrf_field(); ?>
                <div class="col-lg-6 mb-4 mb-lg-0">
                    
                    <div class="px-4">
                        <h3 class="font-weight-bold">Agregar producto a Existencias</h3>
                                <?php echo $__env->make('actualizarstock.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                    </div>
                </div>
                
    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebarauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\webgams\resources\views/actualizarStock/create.blade.php ENDPATH**/ ?>