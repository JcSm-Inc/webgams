

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <?php echo Form::open(['route' => 'solicitud.store','enctype'=>'multipart/form-data','novalidate']); ?>

    <?php echo csrf_field(); ?>
    <div class=" my-5 py-5 z-depth-1">
        <h3 class="font-weight-bold">Nueva hoja de ruta</h3>
        <?php echo $__env->make('solicitudes.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
        
    </div>
    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebarauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\webgams\resources\views/solicitudes/create.blade.php ENDPATH**/ ?>