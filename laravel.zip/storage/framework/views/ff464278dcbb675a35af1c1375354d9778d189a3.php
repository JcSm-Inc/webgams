

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    Producto
                </div>

                <div class="card-body">
                    <img src="<?php echo e(asset($producto->FOTO)); ?>" alt="User Avatar" class="img-size-50 mr-3 img-circle ">
                    <p><strong>CODIGO DE PRODUCTO:</strong><?php echo e($producto->CODPROD); ?></p>
                    <p><strong>NOMBRE:</strong><?php echo e($producto->NOMBRE); ?></p>
                    <p><strong>DESCRIPCION:</strong><?php echo e($producto->DESCRIPCION); ?></p>
                    <p><strong>TIPO:</strong><?php echo e($producto->TIPO); ?></p>
                    <p><strong>STOCK:</strong><?php echo e($producto->STOCK); ?></p>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    HISTORIAL DE ACTUALIZACION DE STOCK
                </div>

                <div class="card-body">
                <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="10px">
                                    FECHA
                                </th>   
                                <th>NRO DOC</th>
                                <th>PROVEEDOR</th>
                                <th>PU</th>
                                <th>CANTIDAD</th>
                                <th colspan="2">&nbsp;</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $actualizaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($stock->FECHA); ?></td>
                                   <td><?php echo e($stock->NRO_DOCUMENTO); ?></td> 
                                   <td><?php echo e($stock->PROVEEDOR); ?></td>
                                   <td><?php echo e($stock->PU); ?></td>
                                   <td><?php echo e($stock->CANTIDAD); ?></td>
                                   <td width="10px">
                                    <a href="<?php echo e(route('productos.edit',$producto)); ?>" class="nav-link">
                                        <i class="far fa-edit"></i>
                                        </a>
                                   </td>
                                   
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts/sidebarauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\webgams\resources\views/actualizarstock/show.blade.php ENDPATH**/ ?>