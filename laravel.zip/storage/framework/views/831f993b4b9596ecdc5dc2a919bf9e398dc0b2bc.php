

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <?php echo Form::open(['route' => 'productos.store','enctype'=>'multipart/form-data','novalidate']); ?>

    <?php echo csrf_field(); ?>
    <div class="row my-5 py-5 z-depth-1">

            <div class="row">

                <div class="col-lg-6 mb-4 mb-lg-0 d-flex align-items-center justify-content-center">
                    <div class="view overlay zoom">
                        <img id="blah" src="<?php echo e(asset('extras/tmp/producto.png')); ?>" class="img-fluid" alt="Producto">
                        <div class="mask flex-center">
                            <label class="btn btn-outline-success btn-file">
                                Subir imagen<input type="file" name="FOTO" id="FOTO" style="display: none;">
                            </label>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 mb-4 mb-lg-0">
                    
                    <div class="px-4">
                        <h3 class="font-weight-bold">Agregar Producto</h3>
                                <?php echo $__env->make('productos.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
                    </div>
                </div>
                
            </div>
    </div>
    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebarauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\webgams\resources\views/productos/create.blade.php ENDPATH**/ ?>