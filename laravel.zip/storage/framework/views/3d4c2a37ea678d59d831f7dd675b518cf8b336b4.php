

<?php $__env->startSection('contenido'); ?>
<section class="content">
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    Actualizar Stock
                </div>

                <div class="card-body">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="10px">
                                    Imagen
                                </th>
                                <th width="10px"> CODPROD </th>     
                                <th>NOMBRE</th>
                                <th>CANTIDAD DISPONIBLE</th>
                                <th>HIST. DE ACT.</th>
                                <th>AGREGAR</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <img src="<?php echo e(asset($producto->FOTO)); ?>" alt="User Avatar" class="img-size-50 mr-3 img-circle ">
                                    </td>
                                   <td><?php echo e($producto->CODPROD); ?></td> 
                                   <td><?php echo e($producto->NOMBRE); ?></td>
                                   <td><?php echo e($producto->STOCK); ?></td>
                                   <td width="10px">
                                       <a href="<?php echo e(route('actualizarstock.show',$producto)); ?>" class="btn btn-sm btn-warning pull-right-align">
                                        <i class="far fa-eye"></i>
                                        </a>
                                    </td>
                                    <td width="10px">
                                       <a href="<?php echo e(route('actualizarstock.create',$producto)); ?>" class="btn btn-sm btn-success pull-right-align">
                                       <i class="fas fa-plus-circle"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($productos->render()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebarauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\webgams\resources\views/actualizarstock/index.blade.php ENDPATH**/ ?>