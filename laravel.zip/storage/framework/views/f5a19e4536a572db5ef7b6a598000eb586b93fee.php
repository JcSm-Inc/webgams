


<div class='md-form'>
    <?php echo e(Form::text('STOCK',null, ['id'=>'STOCK','class'=>'form-control'.( $errors->has('STOCK') ? ' is-invalid' : '' )])); ?>

    <?php echo e(Form::label('inputMDEx','Cantidad')); ?>

    <div class="invalid-feedback">
        <?php $__errorArgs = ['STOCK'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class='md-form'>
    <?php echo e(Form::text('PU',null, ['id'=>'PU','class'=>'form-control'])); ?>

    <?php echo e(Form::label('inputMDEx','PU')); ?>

</div>
<div class='md-form'>
    <?php echo e(Form::text('PROVEEDOR',null, ['id'=>'NOMBRE','class'=>'form-control'.( $errors->has('PROVEEDOR') ? ' is-invalid' : '' )])); ?>

    <?php echo e(Form::label('inputMDEx','Proveedor',['required'])); ?>

    <div class="invalid-feedback">
        <?php $__errorArgs = ['proveedor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class='md-form'>
    <?php echo e(Form::text('NRO_DOCUMENTO',null, ['id'=>'NRO_DOCUMENTO','class'=>'form-control'.( $errors->has('NRO_DOCUMENTO') ? ' is-invalid' : '' )])); ?>

    <?php echo e(Form::label('inputMDEx','Nro de Documento',['required'])); ?>

    <div class="invalid-feedback">
        <?php $__errorArgs = ['proveedor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>



<div class="form-group">
    <?php echo e(Form::submit('Guardar',['type'=>'button','class' => 'btn btn-success'])); ?>

</div><?php /**PATH C:\xampp\htdocs\laravel\webgams\resources\views/actualizarstock/partials/form.blade.php ENDPATH**/ ?>