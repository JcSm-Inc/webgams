
<?php $__env->startSection('contenido'); ?>

<div class="col-md-6 offset-4">
            <!-- general form elements disabled -->
            <div class="card card-green">
                <div class="card-header">
                  <h3 class="card-title">Registro de Nuevo Usuario</h3>
                  <?php if($errors->any()): ?>
                    <p>Hay errores!</p> 
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  <?php endif; ?>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  <form method="POST" role="form" action="<?php echo e(route('register')); ?>">
                  <?php echo csrf_field(); ?>
                    <!-- input states -->
                    <div class="row">
                    <div class="col-md-7 col-sm-4 col-12">
                      <div class="info-box">
                        <div class="info-box-content">
                          <div class="form-group">
                            <label class="col-form-label" for="nick"> Ingrese Nick</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nick'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nick" name="nick" value="<?php echo e(old('nick')); ?>" placeholder="Nick">
                            <?php $__errorArgs = ['nick'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>

                          <div class="form-group">
                            <label class="col-form-label" for="password"> Ingrese Contraseña</label>
                            <input type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password"  placeholder="Contraseña">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                          <div class="form-group">
                            <label class="col-form-label" for="password-confirm"> Repetir Contraseña</label>
                            <input type="password" class="form-control" id="password-confirm" name="password_confirmation" placeholder="Contraseña">
                          </div>

                        </div>
                        <!-- /.info-box-content -->
                      </div>
                    </div>
                      <div class="col-md-5 col-sm-6 col-12">
                        <div class="info-box">

                          <div class="info-box-content">
                              <div class="container">
                                <label class="btn btn-success btn-file">
                                      Subir Fotografia <input type="file" name="FOTO" id="FOTO" style="display: none;">
                                </label>
                                <br >
                                <img id="blah" src="https://via.placeholder.com/150" alt="Tu imagen" height="350" width="500" class="img-thumbnail"/>
                                <?php $__errorArgs = ['FOTO'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                          </div>
                          <!-- /.info-box-content -->
                        </div>
                        <!-- /.info-box -->
                      </div>
                    </div>

                      <!-- /.info-box -->

                        <div class="form-group row">
                            <label class="form-label col-md-3 col-sm-3 col-xs-3" for="CI"> Ingrese C.I.:</label>
                            <div class="col-md-9 col-sm-9 col-xs-9">
                            <input type="text" class="form-control <?php $__errorArgs = ['CI'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="CI" name="CI" value="<?php echo e(old('CI')); ?>" placeholder="C.I." >
                              <?php $__errorArgs = ['CI'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                      <div class="form-group row">
                        <label class="form-label col-md-3 col-sm-3 col-xs-3" for="NOMBRES"> Ingrese Nombres:</label>
                        <div class="col-md-9 col-sm-9 col-xs-9">
                        <input type="text" class="form-control text-uppercase <?php $__errorArgs = ['NOMBRES'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="NOMBRES" name="NOMBRES" value="<?php echo e(old('NOMBRES')); ?>" placeholder="Ingrese Nombres">
                          <?php $__errorArgs = ['NOMBRES'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="form-label col-md-3 col-sm-3 col-xs-3" for="APELLIDOS"> Ingrese Apellidos:</label>
                        <div class="col-md-9 col-sm-9 col-xs-9">
                        <input type="text" class="form-control text-uppercase <?php $__errorArgs = ['APELLIDOS'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " id="APELLIDOS" name="APELLIDOS" value="<?php echo e(old('APELLIDOS')); ?>" placeholder="Ingrese Apellidos">
                          <?php $__errorArgs = ['APELLIDOS'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                      <div class="form-group  row">
                              <label class="form-label col-md-3 col-sm-3 col-xs-3" for="email"> Ingrese email</label>
                              <div class="col-md-9 col-sm-9 col-xs-9">
                              <input type="text" class="form-control text-lowercase <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="ejemplo@ejemplo.com">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                              
                      </div>
                                    <!-- Date -->
                        <div class="form-group row">
                            <label class="form-label col-md-3 col-sm-3 col-xs-3">Fecha de Nacimiento:</label>
                            <div class="col-md-9 col-sm-9 col-xs-9">
                              <div class="input-group date" id="reservationdate" data-target-input="nearest">
                              <input name="FECHANACIMIENTO" id="FECHANACIMIENTO" type="text" class="form-control datetimepicker-input <?php $__errorArgs = ['FECHANACIMIENTO'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('FECHANACIMIENTO')); ?>" data-target="#reservationdate"/>
                                <?php $__errorArgs = ['FECHANACIMIENTO'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="input-group-append" data-target="#reservationdate" data-toggle="datetimepicker">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                            </div>
                        </div>

                        <!-- radio -->
                        <div class="form-group row">
                            <label class="form-label col-md-3 col-sm-3 col-xs-3">Sexo:</label>
                            <div class="col-md-9 col-sm-9 col-xs-9">
                            <div class="col-sm-6">
                      <!-- radio -->
                          <div class="custom-control custom-radio">
                            <input class="custom-control-input" type="radio" id="customRadio1" name="customRadio" value="si" checked>
                            <label for="customRadio1" class="custom-control-label">Varon</label>
                          </div>
                          <div class="custom-control custom-radio">
                            <input class="custom-control-input" type="radio" id="customRadio2" name="customRadio" value="no" >
                            <label for="customRadio2" class="custom-control-label">Mujer</label>
                          </div>
                            </div>
                          </div>
                        </div>
                      
                    

                        <!--<button type="submit" class="btn btn-danger m-md-2 float-right" >Cancelar</button>-->
                        <button type="submit" class="btn btn-success m-md-2 float-right" >Aceptar</button>                   
                  </form>
                </div>
                <!-- /.card-body -->
              </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script src="plugins/jquery/jquery.min.js"></script>
<script>
$(document).ready(function(){
 $(document).on('change', '#file', function(){
  var name = document.getElementById("file").files[0].name;
  var form_data = new FormData();
  var ext = name.split('.').pop().toLowerCase();
  if(jQuery.inArray(ext, ['gif','png','jpg','jpeg']) == -1) 
  {
   alert("No es un archivo de imagen");
  }
  var oFReader = new FileReader();
  oFReader.readAsDataURL(document.getElementById("file").files[0]);
  var f = document.getElementById("file").files[0];
  var fsize = f.size||f.fileSize;
  if(fsize > 2000000)
  {
   alert("El archivo de imagen es muy grande");
  }
  else
  {
   form_data.append("file", document.getElementById('file').files[0]);
   $.ajax({
    url:"./extras/upload.php",
    method:"POST",
    data: form_data,
    contentType: false,
    cache: false,
    processData: false,
    beforeSend:function(){
     $('#uploaded_image').html("<label class='text-success'>Image Uploading...</label>");
    },   
    success:function(data)
    {
     $('#uploaded_image').html(data);
    }
   });
  }
 });
});
</script>

              <!-- /.card -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\webgams\resources\views/auth/register.blade.php ENDPATH**/ ?>