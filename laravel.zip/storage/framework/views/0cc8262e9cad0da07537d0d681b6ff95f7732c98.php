
<?php $__env->startSection('contenido'); ?>        

            <div class="content">
                <div class="title m-b-md">
                <div id="listacategorias"></div>
                </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\webgams\resources\views/welcome.blade.php ENDPATH**/ ?>