

<?php $__env->startSection('contenido'); ?>
<div id="reserva"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebarauth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\webgams\resources\views/reservaProducto/index.blade.php ENDPATH**/ ?>