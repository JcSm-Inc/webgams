<div class='md-form'>
    <?php echo e(Form::text('NOMBRE',null, ['id'=>'REFERENCIA','class'=>'form-control'.( $errors->has('REFERENCIA') ? ' is-invalid' : '' )])); ?>

    <?php echo e(Form::label('inputMDEx','Referencia',['required'])); ?>

    <div class="invalid-feedback">
        <?php $__errorArgs = ['REFERENCIA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

    <div class='md-form'>
        <?php echo e(Form::text('DESTINATARIO',null, ['id'=>'DESTINATARIO','class'=>'form-control'])); ?>

        <?php echo e(Form::label('inputMDEx','Destinatario')); ?>

    </div>
    <div class='md-form'>
        <?php echo e(Form::text('NROHOJAS',null, ['id'=>'NROHOJAS','class'=>'form-control'.( $errors->has('NROHOJAS') ? ' is-invalid' : '' )])); ?>

        <?php echo e(Form::label('inputMDEx','Nro de Hojas')); ?>

        <div class="invalid-feedback">
            <?php $__errorArgs = ['NROHOJAS'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="md-form">
        <input type="file" name="DIRECCION">
    </div>
<div class="form-group">
    <?php echo e(Form::submit('Guardar',['type'=>'button','class' => 'btn btn-success'])); ?>

</div><?php /**PATH C:\xampp\htdocs\laravel\webgams\resources\views/solicitudes/partials/form.blade.php ENDPATH**/ ?>