@extends('layouts.sidebar')
@section('contenido')        

            <div class="content">
                <div class="title m-b-md">
                <div id="listacategorias"></div>
                </div>


</div>
@endsection