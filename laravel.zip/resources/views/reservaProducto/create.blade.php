@extends('layouts.sidebarauth')

@section('contenido')
<div id="listacategorias"></div>
@endsection