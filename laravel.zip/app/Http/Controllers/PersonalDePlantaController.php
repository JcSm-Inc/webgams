<?php

namespace App\Http\Controllers;

use App\Models\Personal_de_Planta;
use Illuminate\Http\Request;

class PersonalDePlantaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Personal_de_Planta  $personal_de_Planta
     * @return \Illuminate\Http\Response
     */
    public function show(Personal_de_Planta $personal_de_Planta)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Personal_de_Planta  $personal_de_Planta
     * @return \Illuminate\Http\Response
     */
    public function edit(Personal_de_Planta $personal_de_Planta)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Personal_de_Planta  $personal_de_Planta
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Personal_de_Planta $personal_de_Planta)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Personal_de_Planta  $personal_de_Planta
     * @return \Illuminate\Http\Response
     */
    public function destroy(Personal_de_Planta $personal_de_Planta)
    {
        //
    }
}
