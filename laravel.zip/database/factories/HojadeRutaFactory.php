<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\HojadeRuta;
use Faker\Generator as Faker;

$factory->define(HojadeRuta::class, function (Faker $faker) {
    return [
        //
    ];
});
