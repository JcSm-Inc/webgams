<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ArchivoAdjuntoComunicado;
use Faker\Generator as Faker;

$factory->define(ArchivoAdjuntoComunicado::class, function (Faker $faker) {
    return [
        //
    ];
});
