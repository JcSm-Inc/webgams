<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\DetalleHojadeRuta;
use Faker\Generator as Faker;

$factory->define(DetalleHojadeRuta::class, function (Faker $faker) {
    return [
        //
    ];
});
