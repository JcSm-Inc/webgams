<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\DetalleReserva;
use Faker\Generator as Faker;

$factory->define(DetalleReserva::class, function (Faker $faker) {
    return [
        //
    ];
});
