<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ArchivoAdjunto;
use Faker\Generator as Faker;

$factory->define(ArchivoAdjunto::class, function (Faker $faker) {
    return [
        //
    ];
});
